Put your Bitdsk IP address into config.js and use your browser to open Bitdsk_Manager.html management.


Bitdsk
Http://www.bitdsk.org