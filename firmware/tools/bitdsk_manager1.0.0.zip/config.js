  /**
   * Please add the IP address you need to manage to All_ip array.
   * 
   * var All_ip=[
   *   "192.168.0.100",
   *   "192.168.0.101",
   *   "192.168.0.101",
   *    ...
   *    ...
   * ];
   * 
   * Note that each IP address needs to be enclosed in double quotes.And English commas.
   * 
   */
var All_ip=[
    "192.168.0.100",
    "192.168.0.101",
];

/**
 * How often to obtain data
 * millisecond
 * default 30000 is 30s
 * It is not recommended to set it too low, as too low a value may cause restart problems caused by WiFi blocking.
*/
var loop_time = 30000;