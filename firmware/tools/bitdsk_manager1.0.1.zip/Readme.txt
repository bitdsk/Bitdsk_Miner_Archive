Copy "config.js.default" to "config.js".
And add Your Bitdsk Miner IP to "config.js" file.

Use your browser to open Bitdsk_Manager.html management.


Bitdsk
Http://www.bitdsk.org